[Note 1]
   The DIF suffix of the attached file is not an installer format,
   It becomes an image after installation deployment.
   
 [Note 2]
   For each "Device_Custom" folder of the attached file,
   Please copy it to CS + installation location.
   (When CS + is installed in drive C)
     CS +:		 "C: \ Program Files \ Renesas Electronics \ CS + \ CC"
                 "C: \ Program Files \ Renesas Electronics \ CS + \ CACX"
   In CS + for CC V 3.01 and earlier, under Device_Custom
   Replace PG_before_CS + _ V 301 with the existing PG.
   (It does not matter if it is as it is)
       �� �� ��
  In the latest release, PG data for "CS + V 3.01 or earlier" is added to the PG folder,
  put PG data for "CS + V 3.02 or later" this time.
  Please be careful when used.

